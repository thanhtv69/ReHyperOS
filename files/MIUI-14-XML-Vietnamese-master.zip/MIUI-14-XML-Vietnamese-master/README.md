[![HyperOS logo](https://camo.githubusercontent.com/1f288ca302011981ebd4e046d694b2d465cf95222552fa7389a5c73e45bf7d17/68747470733a2f2f692e696d6775722e636f6d2f44424566616e712e706e67)](https://miui.vn/)

#  MIUI & HyperOS Vietnamese language Translations.
	This is repository for  MIUI & HyperOS Vietnamese language.

# Translation checker: https://translators.xiaomi.eu/XML_MIUI14-Vietnamese-vi.html

# Credits
    [ingbrzy] - Builder of MultiRom, Bug reports.
    [butinhi] - The Vietnamese language translator for MIUI & HyperOS
    [Belmont] - Leader of the Vietnamese translation team for MIUI
